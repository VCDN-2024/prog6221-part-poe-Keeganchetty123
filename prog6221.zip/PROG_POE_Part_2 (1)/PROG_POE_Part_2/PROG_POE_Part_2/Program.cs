﻿using System;
using System.Collections.Generic;

// Code attribution : https://stackoverflow.com/questions/41421472/how-to-include-multiple-classes-in-one-project-with-one-namespace-how-to-use-the
// Author : Keegan Chetty
// This code was taken from stackoverfolw

class Ingredient
{
    public string Name { get; set; }
    public double Quantity { get; set; }
    public string Unit { get; set; }
    public int Calories { get; set; }
    public string FoodGroup { get; set; }

    public Ingredient(string name, double quantity, string unit, int calories, string foodGroup)
    {
        Name = name;
        Quantity = quantity;
        Unit = unit;
        Calories = calories;
        FoodGroup = foodGroup;
    }
}

class Recipe
{
    private List<Ingredient> ingredients;
    private List<string> steps;
    private int totalCalories;

    public string Name { get; set; }

    public Recipe(string name)
    {
        Name = name;
        ingredients = new List<Ingredient>();
        steps = new List<string>();
    }

    public void AddIngredient(string name, double quantity, string unit, int calories, string foodGroup)
    {
        Ingredient ingredient = new Ingredient(name, quantity, unit, calories, foodGroup);
        ingredients.Add(ingredient);
        totalCalories += calories;
    }

    public void AddStep(string step)
    {
        steps.Add(step);
    }

    public void Display()
    {
        Console.WriteLine("Recipe: " + Name);
        Console.WriteLine("Ingredients:");
        foreach (Ingredient ingredient in ingredients)
        {
            Console.WriteLine("- {0} {1} {2} ({3} calories) [{4}]", ingredient.Quantity, ingredient.Unit, ingredient.Name, ingredient.Calories, ingredient.FoodGroup);
        }

        Console.WriteLine("\nSteps:");
        int count = 1;
        foreach (string step in steps)
        {
            Console.WriteLine("{0}. {1}", count++, step);
        }

        Console.WriteLine("Total Calories: {0}", totalCalories);

        if (totalCalories > 300)
        {
            Console.WriteLine("Warning: This recipe exceeds 300 calories.");
        }
    }

    public void Scale(double factor)
    {
        foreach (Ingredient ingredient in ingredients)
        {
            ingredient.Quantity *= factor;
            ingredient.Calories = (int)Math.Round(ingredient.Calories * factor);
        }
        totalCalories = (int)Math.Round(totalCalories * factor);
    }

    public void Reset()
    {
        foreach (Ingredient ingredient in ingredients)
        {
            ingredient.Quantity /= 2;
            ingredient.Calories /= 2;
        }
        totalCalories /= 2;
    }

    public void Clear()
    {
        ingredients.Clear();
        steps.Clear();
        totalCalories = 0;
    }
}

class RecipeManager
{
    private List<Recipe> recipes;
    public delegate void RecipeCaloriesExceededHandler(Recipe recipe);

    public RecipeManager()
    {
        recipes = new List<Recipe>();
    }

    public void AddRecipe(string name)
    {
        Recipe recipe = new Recipe(name);
        recipes.Add(recipe);
    }

    public void AddIngredient(string recipeName, string name, double quantity, string unit, int calories, string foodGroup)
    {
        Recipe recipe = GetRecipeByName(recipeName);
        if (recipe != null)
        {
            recipe.AddIngredient(name, quantity, unit, calories, foodGroup);
        }
    }

    public void AddStep(string recipeName, string step)
    {
        Recipe recipe = GetRecipeByName(recipeName);
        if (recipe != null)
        {
            recipe.AddStep(step);
        }
    }

    public void DisplayRecipes()
    {
        recipes.Sort((x, y) => string.Compare(x.Name, y.Name));
        foreach (Recipe recipe in recipes)
        {
            Console.WriteLine("- " + recipe.Name);
        }
    }

    public void DisplayRecipe(string recipeName)
    {
        Recipe recipe = GetRecipeByName(recipeName);
        if (recipe != null)
        {
            recipe.Display();
        }
    }

    public void ScaleRecipe(string recipeName, double factor)
    {
        Recipe recipe = GetRecipeByName(recipeName);
        if (recipe != null)
        {
            recipe.Scale(factor);
        }
    }

    public void ResetRecipe(string recipeName)
    {
        Recipe recipe = GetRecipeByName(recipeName);
        if (recipe != null)
        {
            recipe.Reset();
        }
    }

    public void ClearRecipe(string recipeName)
    {
        Recipe recipe = GetRecipeByName(recipeName);
        if (recipe != null)
        {
            recipes.Remove(recipe);
        }
    }

    private Recipe GetRecipeByName(string recipeName)
    {
        return recipes.Find(recipe => recipe.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));
    }
}

class Program
{
    static void Main(string[] args)
    {
        RecipeManager recipeManager = new RecipeManager();

        while (true)
        {
            Console.WriteLine("\n1. Add recipe");
            Console.WriteLine("2. Add ingredient");
            Console.WriteLine("3. Add step");
            Console.WriteLine("4. Display recipes");
            Console.WriteLine("5. Display recipe");
            Console.WriteLine("6. Scale recipe");
            Console.WriteLine("7. Reset quantities");
            Console.WriteLine("8. Clear recipe");
            Console.WriteLine("9. Exit");

            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.Write("Recipe name: ");
                    string recipeName = Console.ReadLine();
                    recipeManager.AddRecipe(recipeName);
                    break;

                case 2:
                    Console.Write("Recipe name: ");
                    recipeName = Console.ReadLine();
                    Console.Write("Ingredient name: ");
                    string ingredientName = Console.ReadLine();
                    Console.Write("Quantity: ");
                    double quantity = double.Parse(Console.ReadLine());
                    Console.Write("Unit: ");
                    string unit = Console.ReadLine();
                    Console.Write("Calories: ");
                    int calories = int.Parse(Console.ReadLine());
                    Console.Write("Food group: ");
                    string foodGroup = Console.ReadLine();
                    recipeManager.AddIngredient(recipeName, ingredientName, quantity, unit, calories, foodGroup);
                    break;

                case 3:
                    Console.Write("Recipe name: ");
                    recipeName = Console.ReadLine();
                    Console.Write("Step: ");
                    string step = Console.ReadLine();
                    recipeManager.AddStep(recipeName, step);
                    break;

                case 4:
                    recipeManager.DisplayRecipes();
                    break;

                case 5:
                    Console.Write("Recipe name: ");
                    recipeName = Console.ReadLine();
                    recipeManager.DisplayRecipe(recipeName);
                    break;

                case 6:
                    Console.Write("Recipe name: ");
                    recipeName = Console.ReadLine();
                    Console.Write("Factor (0.5, 2, or 3): ");
                    double factor = double.Parse(Console.ReadLine());
                    recipeManager.ScaleRecipe(recipeName, factor);
                    break;

                case 7:
                    Console.Write("Recipe name: ");
                    recipeName = Console.ReadLine();
                    recipeManager.ResetRecipe(recipeName);
                    break;

                case 8:
                    Console.Write("Recipe name: ");
                    recipeName = Console.ReadLine();
                    recipeManager.ClearRecipe(recipeName);
                    break;

                case 9:
                    Environment.Exit(0);
                    break;
            }
        }
    }
}
