﻿
namespace RecipeManager
{
    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }

        public Ingredient(string name, double quantity, string unit)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
        }
    }
}


namespace RecipeManager
{
    public class Step
    {
        public string Description { get; set; }

        public Step(string description)
        {
            Description = description;
        }
    }
}




namespace RecipeManager
{
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<Step> Steps { get; set; }

        public Recipe(string name)
        {
            Name = name;
            Ingredients = new List<Ingredient>();
            Steps = new List<Step>();
        }

        public void AddIngredient(Ingredient ingredient)
        {
            Ingredients.Add(ingredient);
        }

        public void AddStep(Step step)
        {
            Steps.Add(step);
        }

        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void DisplayRecipe()
        {
            System.Console.WriteLine($"Recipe: {Name}");
            System.Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                System.Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }
            System.Console.WriteLine("Steps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                System.Console.WriteLine($"{i + 1}. {Steps[i].Description}");
            }
        }
    }
}
