﻿using System;
using System.Collections.Generic;

namespace RecipeManager
{
    class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe("Sample Recipe");

            while (true)
            {
                Console.Clear();
                Console.WriteLine("Recipe Manager");
                Console.WriteLine("1. Add Ingredient");
                Console.WriteLine("2. Add Step");
                Console.WriteLine("3. Display Recipe");
                Console.WriteLine("4. Scale Recipe");
                Console.WriteLine("5. Reset Recipe");
                Console.WriteLine("6. Clear Recipe");
                Console.WriteLine("7. Exit");
                Console.Write("Choose an option: ");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddIngredient(recipe);
                        break;
                    case 2:
                        AddStep(recipe);
                        break;
                    case 3:
                        recipe.DisplayRecipe();
                        Console.ReadKey();
                        break;
                    case 4:
                        ScaleRecipe(recipe);
                        break;
                    case 5:
                        ResetRecipe(recipe);
                        break;
                    case 6:
                        recipe = new Recipe(recipe.Name);
                        break;
                    case 7:
                        return;
                }
            }
        }

        static void AddIngredient(Recipe recipe)
        {
            Console.Write("Enter ingredient name: ");
            string name = Console.ReadLine();
            Console.Write("Enter quantity: ");
            double quantity = double.Parse(Console.ReadLine());
            Console.Write("Enter unit: ");
            string unit = Console.ReadLine();

            recipe.AddIngredient(new Ingredient(name, quantity, unit));
        }

        static void AddStep(Recipe recipe)
        {
            Console.Write("Enter step description: ");
            string description = Console.ReadLine();
            recipe.AddStep(new Step(description));
        }

        static void ScaleRecipe(Recipe recipe)
        {
            Console.Write("Enter scaling factor (0.5, 2, 3): ");
            double factor = double.Parse(Console.ReadLine());
            recipe.ScaleRecipe(factor);
        }

        static void ResetRecipe(Recipe recipe)
        {
            // Logic to reset the recipe if necessary.
        }
    }
}
