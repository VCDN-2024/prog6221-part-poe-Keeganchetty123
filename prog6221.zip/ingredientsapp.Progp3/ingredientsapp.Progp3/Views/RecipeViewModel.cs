﻿using RecipeManager.Models;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;

namespace RecipeManager.ViewModels
{
    public class RecipeViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<Recipe> Recipes { get; set; } = new ObservableCollection<Recipe>();
        public ObservableCollection<Ingredient> Ingredients { get; set; } = new ObservableCollection<Ingredient>();
        public ObservableCollection<Step> Steps { get; set; } = new ObservableCollection<Step>();

        private Recipe _selectedRecipe;
        public Recipe SelectedRecipe
        {
            get => _selectedRecipe;
            set
            {
                _selectedRecipe = value;
                OnPropertyChanged(nameof(SelectedRecipe));
                if (_selectedRecipe != null)
                {
                    Ingredients.Clear();
                    foreach (var ingredient in _selectedRecipe.Ingredients)
                        Ingredients.Add(ingredient);

                    Steps.Clear();
                    foreach (var step in _selectedRecipe.Steps)
                        Steps.Add(step);

                    OnPropertyChanged(nameof(SelectedRecipe.TotalCalories));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        public ICommand ScaleCommand { get; set; }
        public ICommand ResetCommand { get; set; }
        public ICommand ClearCommand { get; set; }

        public RecipeViewModel()
        {
            ScaleCommand = new RelayCommand(param => ScaleRecipe(param.ToString()));
            ResetCommand = new RelayCommand(param => ResetQuantities());
            ClearCommand = new RelayCommand(param => ClearData());
        }

        public void ScaleRecipe(string factorStr)
        {
            if (double.TryParse(factorStr, out double factor))
            {
                foreach (var ingredient in Ingredients)
                {
                    ingredient.Quantity *= factor;
                }
                OnPropertyChanged(nameof(Ingredients));
                OnPropertyChanged(nameof(SelectedRecipe.TotalCalories));
            }
            else
            {
                // Handle invalid input
                System.Windows.MessageBox.Show("Please enter a valid number for scaling.", "Invalid Input", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
            }
        }

        public void ResetQuantities()
        {
            if (SelectedRecipe != null)
            {
                Ingredients.Clear();
                foreach (var ingredient in SelectedRecipe.Ingredients)
                {
                    Ingredients.Add(new Ingredient(
                        ingredient.Name,
                        ingredient.Quantity,
                        ingredient.Unit,
                        ingredient.Calories,
                        ingredient.FoodGroup));
                }
                OnPropertyChanged(nameof(Ingredients));
                OnPropertyChanged(nameof(SelectedRecipe.TotalCalories));
            }
        }

        public void ClearData()
        {
            Recipes.Clear();
            Ingredients.Clear();
            Steps.Clear();
            OnPropertyChanged(nameof(Recipes));
            OnPropertyChanged(nameof(Ingredients));
            OnPropertyChanged(nameof(Steps));
            OnPropertyChanged(nameof(SelectedRecipe.TotalCalories));
        }

        public void AddRecipe(Recipe recipe)
        {
            Recipes.Add(recipe);
            Recipes = new ObservableCollection<Recipe>(Recipes.OrderBy(r => r.Name));
            OnPropertyChanged(nameof(Recipes));
        }

        public int CalculateTotalCalories()
        {
            return Ingredients.Sum(ingredient => ingredient.Calories);
        }

        public void NotifyCaloriesExceeded()
        {
            if (CalculateTotalCalories() > 300)
            {
                System.Windows.MessageBox.Show("Total calories exceed 300!", "Warning", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning);
            }
        }

        public class RelayCommand : ICommand
        {
            private readonly Action<object> _execute;
            private readonly Func<object, bool> _canExecute;

            public event EventHandler CanExecuteChanged;

            public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
            {
                _execute = execute;
                _canExecute = canExecute;
            }

            public bool CanExecute(object parameter)
            {
                return _canExecute == null || _canExecute(parameter);
            }

            public void Execute(object parameter)
            {
                _execute(parameter);
            }
        }
    }
}
