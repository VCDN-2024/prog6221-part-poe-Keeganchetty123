﻿// MainWindow.xaml.cs
using RecipeManager.Models;
using RecipeManager.ViewModels;
using System.Windows;
using System.Windows.Controls;

namespace RecipeManager
{
    public partial class MainWindow : Window
    {
        private RecipeViewModel viewModel;

        public MainWindow()
        {
            InitializeComponent();
            viewModel = DataContext as RecipeViewModel;
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = RecipeNameTextBox.Text.Trim();
            if (!string.IsNullOrEmpty(recipeName))
            {
                viewModel.AddRecipe(new Recipe(recipeName));
                RecipeNameTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a valid recipe name.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            if (viewModel.SelectedRecipe != null)
            {
                string name = IngredientNameTextBox.Text.Trim();
                string quantityText = IngredientQuantityTextBox.Text.Trim();
                string unit = (IngredientUnitComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
                string caloriesText = IngredientCaloriesTextBox.Text.Trim();
                string foodGroup = (IngredientFoodGroupComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();

                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(unit) || string.IsNullOrEmpty(foodGroup))
                {
                    MessageBox.Show("Please fill in all ingredient fields.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (!double.TryParse(quantityText, out double quantity))
                {
                    MessageBox.Show("Please enter a valid numeric value for quantity.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (!int.TryParse(caloriesText, out int calories))
                {
                    MessageBox.Show("Please enter a valid numeric value for calories.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                var ingredient = new Ingredient(name, quantity, unit, calories, foodGroup);
                viewModel.SelectedRecipe.Ingredients.Add(ingredient);
                viewModel.Ingredients.Add(ingredient);

                IngredientNameTextBox.Clear();
                IngredientQuantityTextBox.Clear();
                IngredientUnitComboBox.SelectedIndex = -1;
                IngredientCaloriesTextBox.Clear();
                IngredientFoodGroupComboBox.SelectedIndex = -1;

                viewModel.NotifyCaloriesExceeded();
            }
            else
            {
                MessageBox.Show("Please select a recipe first.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddStep_Click(object sender, RoutedEventArgs e)
        {
            if (viewModel.SelectedRecipe != null)
            {
                string description = StepDescriptionTextBox.Text.Trim();
                if (!string.IsNullOrEmpty(description))
                {
                    var step = new Step(description);
                    viewModel.SelectedRecipe.Steps.Add(step);
                    viewModel.Steps.Add(step);
                    StepDescriptionTextBox.Clear();
                }
                else
                {
                    MessageBox.Show("Please enter a valid step description.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a recipe first.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
