﻿// Ingredient.cs
namespace RecipeManager.Models
{
    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }

        public Ingredient(string name, double quantity, string unit, int calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }
    }
}

// Step.cs
namespace RecipeManager.Models
{
    public class Step
    {
        public string Description { get; set; }

        public Step(string description)
        {
            Description = description;
        }
    }
}




namespace RecipeManager.Models
{
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; } = new List<Ingredient>();
        public List<Step> Steps { get; set; } = new List<Step>();

        public Recipe(string name)
        {
            Name = name;
        }

        public int TotalCalories => Ingredients.Sum(ingredient => ingredient.Calories);
    }
}
